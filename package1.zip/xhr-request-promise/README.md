## xhr-request-promise

Thin wrapper on top of [this](https://www.npmjs.com/package/xhr-request) to use Promise instead of callbacks.
