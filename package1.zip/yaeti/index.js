module.exports = {
	EventTarget : require('./lib/EventTarget'),
	Event       : require('./lib/Event')
};
